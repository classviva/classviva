package com.mo.mapper;

/**
 * @create 2022-05-04 17:54
 */
public interface ScheduleMapper {
}
